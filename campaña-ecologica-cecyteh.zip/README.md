# Campaña Ecológica Cecyteh Tizayuca

Este proyecto es una página web informativa sobre la campaña ecológica de reciclaje realizada en la escuela Cecyteh Tizayuca.

## Archivos

- `index.html`: Página principal.
- `style.css`: Estilos del sitio.
- `script.js`: Funcionalidades JavaScript.

## Objetivo

Fomentar el reciclaje escolar mediante una interfaz visual y accesible.

---

Creado como parte de una iniciativa ecológica educativa.
